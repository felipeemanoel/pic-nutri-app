// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get languageTitle => '语言';

  @override
  String get languageChooseTitle => '选择应用语言';

  @override
  String get languageChooseSubtitle => '你可以随时在“个人资料 › 语言”中更改。';

  @override
  String get languageFollowDevice => '使用设备语言';

  @override
  String get languageInProgress => '翻译进行中';

  @override
  String get languageChange => '更改语言';

  @override
  String get languageChangeShort => '更改';

  @override
  String get authTagline => '一个照顾自己的空间。';

  @override
  String get authFooter => '按你的节奏，见证你的进步。';

  @override
  String get onboardingWelcomeTitle => '来制定你的计划吧';

  @override
  String get onboardingWelcomeSubtitle =>
      '回答几个简单的问题，PicNutri 就会为你量身调整。大约需要 2 分钟。';

  @override
  String get onboardingWelcomePhotoTitle => '拍照记录';

  @override
  String get onboardingWelcomePhotoText => '拍下餐盘，查看估算的热量和宏量营养素。';

  @override
  String get onboardingWelcomeGoalsTitle => '为你定制的目标';

  @override
  String get onboardingWelcomeGoalsText => '根据你的数据计算热量、蛋白质和饮水量。';

  @override
  String get onboardingWelcomeProgressTitle => '查看你的进展';

  @override
  String get onboardingWelcomeProgressText => '用简单的图表呈现体重、围度和习惯。';

  @override
  String get actionStart => '开始';

  @override
  String get actionStartUsing => '开始使用';

  @override
  String get actionContinue => '继续';

  @override
  String get profileTitle => '个人资料';

  @override
  String get profileSectionAccount => '账户';

  @override
  String get profileSectionPreferences => '偏好设置';

  @override
  String get profileSectionHelp => '帮助';

  @override
  String get profileGoals => '个人资料、目标与指标';

  @override
  String profileWater(String amount) {
    return '饮水 $amount';
  }

  @override
  String get profileMyPlan => '我的方案';

  @override
  String get profileProfessionals => '专业人士';

  @override
  String get profileProfessionalsSubtitle => '寻找营养师和健身专业人士';

  @override
  String get profileTrackMedication => '记录用药';

  @override
  String get profileTrackMedicationSubtitle => '在“进展”中记录处方用药和症状';

  @override
  String get profileSignInMethods => '登录方式';

  @override
  String get profileSignInMethodsSubtitle => '密码、Google、Facebook 和 Apple';

  @override
  String get profilePrivacy => '隐私与数据';

  @override
  String get profilePrivacySubtitle => '授权、导出和删除账户';

  @override
  String get profileNotifications => '通知与提醒';

  @override
  String get profileNotificationsOn => '已在此设备上开启';

  @override
  String get profileNotificationsOff => '已在此设备上关闭';

  @override
  String get profileTheme => '主题';

  @override
  String get themeSystem => '跟随系统';

  @override
  String get themeLight => '浅色';

  @override
  String get themeDark => '深色';

  @override
  String get profileAssistant => '助手';

  @override
  String get profileAssistantSubtitle => '查看你的记录并咨询应用相关问题';

  @override
  String get profileHelpCenter => '帮助中心';

  @override
  String get profileHelpCenterSubtitle => '常见问题与使用指南';

  @override
  String get profileServerStatusDev => '服务器状态（开发）';

  @override
  String get profileLogout => '退出登录';

  @override
  String get profileLogoutConfirmTitle => '要退出登录吗？';

  @override
  String get profileLogoutConfirmMessage => '你需要在此设备上重新登录。';
}
