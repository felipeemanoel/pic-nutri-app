// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get languageTitle => 'Idioma';

  @override
  String get languageChooseTitle => 'Elige el idioma de la app';

  @override
  String get languageChooseSubtitle =>
      'Puedes cambiarlo cuando quieras en Perfil › Idioma.';

  @override
  String get languageFollowDevice => 'Usar el idioma del dispositivo';

  @override
  String get languageInProgress => 'Traducción en curso';

  @override
  String get languageChange => 'Cambiar idioma';

  @override
  String get languageChangeShort => 'Cambiar';

  @override
  String get authTagline => 'Un espacio para cuidarte.';

  @override
  String get authFooter => 'Tu evolución, a tu ritmo.';

  @override
  String get onboardingWelcomeTitle => 'Vamos a armar tu plan';

  @override
  String get onboardingWelcomeSubtitle =>
      'Responde unas preguntas rápidas y PicNutri se adapta a ti. Toma unos 2 minutos.';

  @override
  String get onboardingWelcomePhotoTitle => 'Registra con una foto';

  @override
  String get onboardingWelcomePhotoText =>
      'Fotografía tu plato y ve las calorías y macros estimadas.';

  @override
  String get onboardingWelcomeGoalsTitle => 'Metas hechas para ti';

  @override
  String get onboardingWelcomeGoalsText =>
      'Calorías, proteína y agua calculadas con tus datos.';

  @override
  String get onboardingWelcomeProgressTitle => 'Mira tu evolución';

  @override
  String get onboardingWelcomeProgressText =>
      'Peso, medidas y hábitos en gráficos sencillos.';

  @override
  String get actionStart => 'Empezar';

  @override
  String get actionStartUsing => 'Empezar a usar';

  @override
  String get actionContinue => 'Continuar';

  @override
  String get profileTitle => 'Perfil';

  @override
  String get profileSectionAccount => 'Cuenta';

  @override
  String get profileSectionPreferences => 'Preferencias';

  @override
  String get profileSectionHelp => 'Ayuda';

  @override
  String get profileGoals => 'Perfil, objetivo y metas';

  @override
  String profileWater(String amount) {
    return 'Agua $amount';
  }

  @override
  String get profileMyPlan => 'Mi plan';

  @override
  String get profileProfessionals => 'Profesionales';

  @override
  String get profileProfessionalsSubtitle =>
      'Encuentra nutricionistas y profesionales de educación física';

  @override
  String get profileTrackMedication => 'Seguir medicamento';

  @override
  String get profileTrackMedicationSubtitle =>
      'Registra aplicaciones prescritas y síntomas en Evolución';

  @override
  String get profileSignInMethods => 'Formas de acceso';

  @override
  String get profileSignInMethodsSubtitle =>
      'Contraseña, Google, Facebook y Apple';

  @override
  String get profilePrivacy => 'Privacidad y datos';

  @override
  String get profilePrivacySubtitle =>
      'Autorizaciones, exportación y eliminación de la cuenta';

  @override
  String get profileNotifications => 'Notificaciones y recordatorios';

  @override
  String get profileNotificationsOn => 'Activadas en este dispositivo';

  @override
  String get profileNotificationsOff => 'Desactivadas en este dispositivo';

  @override
  String get profileTheme => 'Tema';

  @override
  String get themeSystem => 'Sistema';

  @override
  String get themeLight => 'Claro';

  @override
  String get themeDark => 'Oscuro';

  @override
  String get profileAssistant => 'Asistente';

  @override
  String get profileAssistantSubtitle =>
      'Consulta tus registros y resuelve dudas sobre la app';

  @override
  String get profileHelpCenter => 'Centro de ayuda';

  @override
  String get profileHelpCenterSubtitle => 'Preguntas frecuentes y guías de uso';

  @override
  String get profileServerStatusDev => 'Estado del servidor (desarrollo)';

  @override
  String get profileLogout => 'Cerrar sesión';

  @override
  String get profileLogoutConfirmTitle => '¿Cerrar sesión?';

  @override
  String get profileLogoutConfirmMessage =>
      'Tendrás que volver a iniciar sesión en este dispositivo.';
}
