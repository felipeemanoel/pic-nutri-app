// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Japanese (`ja`).
class AppLocalizationsJa extends AppLocalizations {
  AppLocalizationsJa([String locale = 'ja']) : super(locale);

  @override
  String get languageTitle => '言語';

  @override
  String get languageChooseTitle => 'アプリの言語を選択';

  @override
  String get languageChooseSubtitle => '「プロフィール › 言語」からいつでも変更できます。';

  @override
  String get languageFollowDevice => '端末の言語を使用';

  @override
  String get languageInProgress => '翻訳中';

  @override
  String get languageChange => '言語を変更';

  @override
  String get languageChangeShort => '変更';

  @override
  String get authTagline => '自分を大切にするための場所。';

  @override
  String get authFooter => 'あなたのペースで、あなたの成長を。';

  @override
  String get onboardingWelcomeTitle => 'あなたのプランを作りましょう';

  @override
  String get onboardingWelcomeSubtitle =>
      'いくつかの簡単な質問に答えると、PicNutri があなたに合わせて調整します。所要時間は約2分です。';

  @override
  String get onboardingWelcomePhotoTitle => '写真で記録';

  @override
  String get onboardingWelcomePhotoText => 'お皿を撮影して、推定カロリーと栄養素を確認。';

  @override
  String get onboardingWelcomeGoalsTitle => 'あなたに合わせた目標';

  @override
  String get onboardingWelcomeGoalsText => 'カロリー、たんぱく質、水分をあなたのデータから計算。';

  @override
  String get onboardingWelcomeProgressTitle => '成長を確認';

  @override
  String get onboardingWelcomeProgressText => '体重・サイズ・習慣をシンプルなグラフで。';

  @override
  String get actionStart => 'はじめる';

  @override
  String get actionStartUsing => '使い始める';

  @override
  String get actionContinue => '続ける';

  @override
  String get profileTitle => 'プロフィール';

  @override
  String get profileSectionAccount => 'アカウント';

  @override
  String get profileSectionPreferences => '設定';

  @override
  String get profileSectionHelp => 'ヘルプ';

  @override
  String get profileGoals => 'プロフィール・目的・目標';

  @override
  String profileWater(String amount) {
    return '水分 $amount';
  }

  @override
  String get profileMyPlan => 'マイプラン';

  @override
  String get profileProfessionals => '専門家';

  @override
  String get profileProfessionalsSubtitle => '管理栄養士や運動指導者を探す';

  @override
  String get profileTrackMedication => '薬を記録';

  @override
  String get profileTrackMedicationSubtitle => '処方された投与と症状を「経過」に記録';

  @override
  String get profileSignInMethods => 'ログイン方法';

  @override
  String get profileSignInMethodsSubtitle => 'パスワード、Google、Facebook、Apple';

  @override
  String get profilePrivacy => 'プライバシーとデータ';

  @override
  String get profilePrivacySubtitle => '同意、エクスポート、アカウント削除';

  @override
  String get profileNotifications => '通知とリマインダー';

  @override
  String get profileNotificationsOn => 'この端末でオン';

  @override
  String get profileNotificationsOff => 'この端末でオフ';

  @override
  String get profileTheme => 'テーマ';

  @override
  String get themeSystem => 'システム';

  @override
  String get themeLight => 'ライト';

  @override
  String get themeDark => 'ダーク';

  @override
  String get profileAssistant => 'アシスタント';

  @override
  String get profileAssistantSubtitle => '記録を確認し、アプリについて質問できます';

  @override
  String get profileHelpCenter => 'ヘルプセンター';

  @override
  String get profileHelpCenterSubtitle => 'よくある質問と使い方ガイド';

  @override
  String get profileServerStatusDev => 'サーバーの状態（開発）';

  @override
  String get profileLogout => 'ログアウト';

  @override
  String get profileLogoutConfirmTitle => 'ログアウトしますか？';

  @override
  String get profileLogoutConfirmMessage => 'この端末で再度ログインが必要になります。';
}
