// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get languageTitle => 'Idioma';

  @override
  String get languageChooseTitle => 'Escolha o idioma do app';

  @override
  String get languageChooseSubtitle =>
      'Você pode mudar quando quiser em Perfil › Idioma.';

  @override
  String get languageFollowDevice => 'Usar o idioma do aparelho';

  @override
  String get languageInProgress => 'Tradução em andamento';

  @override
  String get languageChange => 'Mudar idioma';

  @override
  String get languageChangeShort => 'Alterar';

  @override
  String get authTagline => 'Um espaço para cuidar de você.';

  @override
  String get authFooter => 'Sua evolução, no seu ritmo.';

  @override
  String get onboardingWelcomeTitle => 'Vamos montar o seu plano';

  @override
  String get onboardingWelcomeSubtitle =>
      'Responda algumas perguntas rápidas e o PicNutri se ajusta a você. Leva cerca de 2 minutos.';

  @override
  String get onboardingWelcomePhotoTitle => 'Registre por foto';

  @override
  String get onboardingWelcomePhotoText =>
      'Fotografe o prato e veja calorias e macros estimados.';

  @override
  String get onboardingWelcomeGoalsTitle => 'Metas feitas para você';

  @override
  String get onboardingWelcomeGoalsText =>
      'Calorias, proteína e água calculadas com os seus dados.';

  @override
  String get onboardingWelcomeProgressTitle => 'Veja a sua evolução';

  @override
  String get onboardingWelcomeProgressText =>
      'Peso, medidas e hábitos em gráficos simples.';

  @override
  String get actionStart => 'Começar';

  @override
  String get actionStartUsing => 'Começar a usar';

  @override
  String get actionContinue => 'Continuar';

  @override
  String get profileTitle => 'Perfil';

  @override
  String get profileSectionAccount => 'Conta';

  @override
  String get profileSectionPreferences => 'Preferências';

  @override
  String get profileSectionHelp => 'Ajuda';

  @override
  String get profileGoals => 'Perfil, objetivo e metas';

  @override
  String profileWater(String amount) {
    return 'Água $amount';
  }

  @override
  String get profileMyPlan => 'Meu plano';

  @override
  String get profileProfessionals => 'Profissionais';

  @override
  String get profileProfessionalsSubtitle =>
      'Encontre nutricionistas e educadores físicos';

  @override
  String get profileTrackMedication => 'Acompanhar medicamento';

  @override
  String get profileTrackMedicationSubtitle =>
      'Registre aplicações prescritas e sintomas na Evolução';

  @override
  String get profileSignInMethods => 'Formas de acesso';

  @override
  String get profileSignInMethodsSubtitle => 'Senha, Google, Facebook e Apple';

  @override
  String get profilePrivacy => 'Privacidade e dados';

  @override
  String get profilePrivacySubtitle =>
      'Autorizações, exportação e exclusão da conta';

  @override
  String get profileNotifications => 'Notificações e lembretes';

  @override
  String get profileNotificationsOn => 'Ativadas neste aparelho';

  @override
  String get profileNotificationsOff => 'Desativadas neste aparelho';

  @override
  String get profileTheme => 'Tema';

  @override
  String get themeSystem => 'Sistema';

  @override
  String get themeLight => 'Claro';

  @override
  String get themeDark => 'Escuro';

  @override
  String get profileAssistant => 'Assistente';

  @override
  String get profileAssistantSubtitle =>
      'Consulte seus registros e tire dúvidas sobre o app';

  @override
  String get profileHelpCenter => 'Central de ajuda';

  @override
  String get profileHelpCenterSubtitle =>
      'Perguntas frequentes e orientações de uso';

  @override
  String get profileServerStatusDev => 'Status do servidor (desenvolvimento)';

  @override
  String get profileLogout => 'Sair';

  @override
  String get profileLogoutConfirmTitle => 'Sair da conta?';

  @override
  String get profileLogoutConfirmMessage =>
      'Você precisará entrar novamente neste aparelho.';
}
