import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_ja.dart';
import 'app_localizations_pt.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('de'),
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('ja'),
    Locale('pt'),
    Locale('zh'),
  ];

  /// Título da seção/folha de idioma
  ///
  /// In pt, this message translates to:
  /// **'Idioma'**
  String get languageTitle;

  /// Título da folha de seleção
  ///
  /// In pt, this message translates to:
  /// **'Escolha o idioma do app'**
  String get languageChooseTitle;

  /// Subtítulo da folha de seleção
  ///
  /// In pt, this message translates to:
  /// **'Você pode mudar quando quiser em Perfil › Idioma.'**
  String get languageChooseSubtitle;

  /// Opção que segue o idioma do sistema
  ///
  /// In pt, this message translates to:
  /// **'Usar o idioma do aparelho'**
  String get languageFollowDevice;

  /// Aviso em idiomas ainda não concluídos
  ///
  /// In pt, this message translates to:
  /// **'Tradução em andamento'**
  String get languageInProgress;

  /// Rótulo/tooltip do botão de idioma
  ///
  /// In pt, this message translates to:
  /// **'Mudar idioma'**
  String get languageChange;

  /// Ação curta ao lado do idioma atual
  ///
  /// In pt, this message translates to:
  /// **'Alterar'**
  String get languageChangeShort;

  /// Frase abaixo da marca nas telas de conta
  ///
  /// In pt, this message translates to:
  /// **'Um espaço para cuidar de você.'**
  String get authTagline;

  /// Rodapé das telas de conta
  ///
  /// In pt, this message translates to:
  /// **'Sua evolução, no seu ritmo.'**
  String get authFooter;

  /// Título da primeira tela do cadastro
  ///
  /// In pt, this message translates to:
  /// **'Vamos montar o seu plano'**
  String get onboardingWelcomeTitle;

  /// No description provided for @onboardingWelcomeSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Responda algumas perguntas rápidas e o PicNutri se ajusta a você. Leva cerca de 2 minutos.'**
  String get onboardingWelcomeSubtitle;

  /// No description provided for @onboardingWelcomePhotoTitle.
  ///
  /// In pt, this message translates to:
  /// **'Registre por foto'**
  String get onboardingWelcomePhotoTitle;

  /// No description provided for @onboardingWelcomePhotoText.
  ///
  /// In pt, this message translates to:
  /// **'Fotografe o prato e veja calorias e macros estimados.'**
  String get onboardingWelcomePhotoText;

  /// No description provided for @onboardingWelcomeGoalsTitle.
  ///
  /// In pt, this message translates to:
  /// **'Metas feitas para você'**
  String get onboardingWelcomeGoalsTitle;

  /// No description provided for @onboardingWelcomeGoalsText.
  ///
  /// In pt, this message translates to:
  /// **'Calorias, proteína e água calculadas com os seus dados.'**
  String get onboardingWelcomeGoalsText;

  /// No description provided for @onboardingWelcomeProgressTitle.
  ///
  /// In pt, this message translates to:
  /// **'Veja a sua evolução'**
  String get onboardingWelcomeProgressTitle;

  /// No description provided for @onboardingWelcomeProgressText.
  ///
  /// In pt, this message translates to:
  /// **'Peso, medidas e hábitos em gráficos simples.'**
  String get onboardingWelcomeProgressText;

  /// Botão da primeira tela do cadastro
  ///
  /// In pt, this message translates to:
  /// **'Começar'**
  String get actionStart;

  /// Botão da última tela do cadastro
  ///
  /// In pt, this message translates to:
  /// **'Começar a usar'**
  String get actionStartUsing;

  /// No description provided for @actionContinue.
  ///
  /// In pt, this message translates to:
  /// **'Continuar'**
  String get actionContinue;

  /// Título da aba Perfil
  ///
  /// In pt, this message translates to:
  /// **'Perfil'**
  String get profileTitle;

  /// No description provided for @profileSectionAccount.
  ///
  /// In pt, this message translates to:
  /// **'Conta'**
  String get profileSectionAccount;

  /// No description provided for @profileSectionPreferences.
  ///
  /// In pt, this message translates to:
  /// **'Preferências'**
  String get profileSectionPreferences;

  /// No description provided for @profileSectionHelp.
  ///
  /// In pt, this message translates to:
  /// **'Ajuda'**
  String get profileSectionHelp;

  /// No description provided for @profileGoals.
  ///
  /// In pt, this message translates to:
  /// **'Perfil, objetivo e metas'**
  String get profileGoals;

  /// Meta de água no resumo do perfil
  ///
  /// In pt, this message translates to:
  /// **'Água {amount}'**
  String profileWater(String amount);

  /// Assinatura (plano pago)
  ///
  /// In pt, this message translates to:
  /// **'Meu plano'**
  String get profileMyPlan;

  /// No description provided for @profileProfessionals.
  ///
  /// In pt, this message translates to:
  /// **'Profissionais'**
  String get profileProfessionals;

  /// No description provided for @profileProfessionalsSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Encontre nutricionistas e educadores físicos'**
  String get profileProfessionalsSubtitle;

  /// No description provided for @profileTrackMedication.
  ///
  /// In pt, this message translates to:
  /// **'Acompanhar medicamento'**
  String get profileTrackMedication;

  /// No description provided for @profileTrackMedicationSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Registre aplicações prescritas e sintomas na Evolução'**
  String get profileTrackMedicationSubtitle;

  /// No description provided for @profileSignInMethods.
  ///
  /// In pt, this message translates to:
  /// **'Formas de acesso'**
  String get profileSignInMethods;

  /// No description provided for @profileSignInMethodsSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Senha, Google, Facebook e Apple'**
  String get profileSignInMethodsSubtitle;

  /// No description provided for @profilePrivacy.
  ///
  /// In pt, this message translates to:
  /// **'Privacidade e dados'**
  String get profilePrivacy;

  /// No description provided for @profilePrivacySubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Autorizações, exportação e exclusão da conta'**
  String get profilePrivacySubtitle;

  /// No description provided for @profileNotifications.
  ///
  /// In pt, this message translates to:
  /// **'Notificações e lembretes'**
  String get profileNotifications;

  /// No description provided for @profileNotificationsOn.
  ///
  /// In pt, this message translates to:
  /// **'Ativadas neste aparelho'**
  String get profileNotificationsOn;

  /// No description provided for @profileNotificationsOff.
  ///
  /// In pt, this message translates to:
  /// **'Desativadas neste aparelho'**
  String get profileNotificationsOff;

  /// No description provided for @profileTheme.
  ///
  /// In pt, this message translates to:
  /// **'Tema'**
  String get profileTheme;

  /// No description provided for @themeSystem.
  ///
  /// In pt, this message translates to:
  /// **'Sistema'**
  String get themeSystem;

  /// No description provided for @themeLight.
  ///
  /// In pt, this message translates to:
  /// **'Claro'**
  String get themeLight;

  /// No description provided for @themeDark.
  ///
  /// In pt, this message translates to:
  /// **'Escuro'**
  String get themeDark;

  /// No description provided for @profileAssistant.
  ///
  /// In pt, this message translates to:
  /// **'Assistente'**
  String get profileAssistant;

  /// No description provided for @profileAssistantSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Consulte seus registros e tire dúvidas sobre o app'**
  String get profileAssistantSubtitle;

  /// No description provided for @profileHelpCenter.
  ///
  /// In pt, this message translates to:
  /// **'Central de ajuda'**
  String get profileHelpCenter;

  /// No description provided for @profileHelpCenterSubtitle.
  ///
  /// In pt, this message translates to:
  /// **'Perguntas frequentes e orientações de uso'**
  String get profileHelpCenterSubtitle;

  /// No description provided for @profileServerStatusDev.
  ///
  /// In pt, this message translates to:
  /// **'Status do servidor (desenvolvimento)'**
  String get profileServerStatusDev;

  /// No description provided for @profileLogout.
  ///
  /// In pt, this message translates to:
  /// **'Sair'**
  String get profileLogout;

  /// No description provided for @profileLogoutConfirmTitle.
  ///
  /// In pt, this message translates to:
  /// **'Sair da conta?'**
  String get profileLogoutConfirmTitle;

  /// No description provided for @profileLogoutConfirmMessage.
  ///
  /// In pt, this message translates to:
  /// **'Você precisará entrar novamente neste aparelho.'**
  String get profileLogoutConfirmMessage;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
    'de',
    'en',
    'es',
    'fr',
    'ja',
    'pt',
    'zh',
  ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'de':
      return AppLocalizationsDe();
    case 'en':
      return AppLocalizationsEn();
    case 'es':
      return AppLocalizationsEs();
    case 'fr':
      return AppLocalizationsFr();
    case 'ja':
      return AppLocalizationsJa();
    case 'pt':
      return AppLocalizationsPt();
    case 'zh':
      return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
