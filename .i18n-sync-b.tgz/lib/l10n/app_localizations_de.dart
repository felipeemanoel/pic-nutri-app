// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for German (`de`).
class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get languageTitle => 'Sprache';

  @override
  String get languageChooseTitle => 'Wähle die App-Sprache';

  @override
  String get languageChooseSubtitle =>
      'Du kannst sie jederzeit unter Profil › Sprache ändern.';

  @override
  String get languageFollowDevice => 'Gerätesprache verwenden';

  @override
  String get languageInProgress => 'Übersetzung in Arbeit';

  @override
  String get languageChange => 'Sprache ändern';

  @override
  String get languageChangeShort => 'Ändern';

  @override
  String get authTagline => 'Ein Ort, um auf dich zu achten.';

  @override
  String get authFooter => 'Dein Fortschritt, in deinem Tempo.';

  @override
  String get onboardingWelcomeTitle => 'Lass uns deinen Plan erstellen';

  @override
  String get onboardingWelcomeSubtitle =>
      'Beantworte ein paar kurze Fragen und PicNutri passt sich an dich an. Das dauert etwa 2 Minuten.';

  @override
  String get onboardingWelcomePhotoTitle => 'Per Foto erfassen';

  @override
  String get onboardingWelcomePhotoText =>
      'Fotografiere deinen Teller und sieh geschätzte Kalorien und Makros.';

  @override
  String get onboardingWelcomeGoalsTitle => 'Ziele, die zu dir passen';

  @override
  String get onboardingWelcomeGoalsText =>
      'Kalorien, Protein und Wasser, berechnet aus deinen Daten.';

  @override
  String get onboardingWelcomeProgressTitle => 'Sieh deinen Fortschritt';

  @override
  String get onboardingWelcomeProgressText =>
      'Gewicht, Maße und Gewohnheiten in einfachen Diagrammen.';

  @override
  String get actionStart => 'Los geht\'s';

  @override
  String get actionStartUsing => 'Jetzt starten';

  @override
  String get actionContinue => 'Weiter';

  @override
  String get profileTitle => 'Profil';

  @override
  String get profileSectionAccount => 'Konto';

  @override
  String get profileSectionPreferences => 'Einstellungen';

  @override
  String get profileSectionHelp => 'Hilfe';

  @override
  String get profileGoals => 'Profil, Ziel und Vorgaben';

  @override
  String profileWater(String amount) {
    return 'Wasser $amount';
  }

  @override
  String get profileMyPlan => 'Mein Tarif';

  @override
  String get profileProfessionals => 'Fachleute';

  @override
  String get profileProfessionalsSubtitle =>
      'Finde Ernährungsberater und Fitnessprofis';

  @override
  String get profileTrackMedication => 'Medikament verfolgen';

  @override
  String get profileTrackMedicationSubtitle =>
      'Erfasse verschriebene Anwendungen und Symptome unter Fortschritt';

  @override
  String get profileSignInMethods => 'Anmeldemethoden';

  @override
  String get profileSignInMethodsSubtitle =>
      'Passwort, Google, Facebook und Apple';

  @override
  String get profilePrivacy => 'Datenschutz und Daten';

  @override
  String get profilePrivacySubtitle =>
      'Einwilligungen, Export und Kontolöschung';

  @override
  String get profileNotifications => 'Benachrichtigungen und Erinnerungen';

  @override
  String get profileNotificationsOn => 'Auf diesem Gerät aktiviert';

  @override
  String get profileNotificationsOff => 'Auf diesem Gerät deaktiviert';

  @override
  String get profileTheme => 'Design';

  @override
  String get themeSystem => 'System';

  @override
  String get themeLight => 'Hell';

  @override
  String get themeDark => 'Dunkel';

  @override
  String get profileAssistant => 'Assistent';

  @override
  String get profileAssistantSubtitle =>
      'Sieh deine Einträge ein und stelle Fragen zur App';

  @override
  String get profileHelpCenter => 'Hilfe-Center';

  @override
  String get profileHelpCenterSubtitle => 'Häufige Fragen und Anleitungen';

  @override
  String get profileServerStatusDev => 'Serverstatus (Entwicklung)';

  @override
  String get profileLogout => 'Abmelden';

  @override
  String get profileLogoutConfirmTitle => 'Abmelden?';

  @override
  String get profileLogoutConfirmMessage =>
      'Du musst dich auf diesem Gerät erneut anmelden.';
}
