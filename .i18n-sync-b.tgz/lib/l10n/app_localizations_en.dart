// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get languageTitle => 'Language';

  @override
  String get languageChooseTitle => 'Choose the app language';

  @override
  String get languageChooseSubtitle =>
      'You can change it anytime in Profile › Language.';

  @override
  String get languageFollowDevice => 'Use device language';

  @override
  String get languageInProgress => 'Translation in progress';

  @override
  String get languageChange => 'Change language';

  @override
  String get languageChangeShort => 'Change';

  @override
  String get authTagline => 'A space to take care of yourself.';

  @override
  String get authFooter => 'Your progress, at your pace.';

  @override
  String get onboardingWelcomeTitle => 'Let\'s build your plan';

  @override
  String get onboardingWelcomeSubtitle =>
      'Answer a few quick questions and PicNutri adapts to you. It takes about 2 minutes.';

  @override
  String get onboardingWelcomePhotoTitle => 'Log by photo';

  @override
  String get onboardingWelcomePhotoText =>
      'Snap your plate and see estimated calories and macros.';

  @override
  String get onboardingWelcomeGoalsTitle => 'Goals made for you';

  @override
  String get onboardingWelcomeGoalsText =>
      'Calories, protein and water calculated from your data.';

  @override
  String get onboardingWelcomeProgressTitle => 'See your progress';

  @override
  String get onboardingWelcomeProgressText =>
      'Weight, measurements and habits in simple charts.';

  @override
  String get actionStart => 'Get started';

  @override
  String get actionStartUsing => 'Start using';

  @override
  String get actionContinue => 'Continue';

  @override
  String get profileTitle => 'Profile';

  @override
  String get profileSectionAccount => 'Account';

  @override
  String get profileSectionPreferences => 'Preferences';

  @override
  String get profileSectionHelp => 'Help';

  @override
  String get profileGoals => 'Profile, goal and targets';

  @override
  String profileWater(String amount) {
    return 'Water $amount';
  }

  @override
  String get profileMyPlan => 'My plan';

  @override
  String get profileProfessionals => 'Professionals';

  @override
  String get profileProfessionalsSubtitle =>
      'Find dietitians and fitness professionals';

  @override
  String get profileTrackMedication => 'Track medication';

  @override
  String get profileTrackMedicationSubtitle =>
      'Log prescribed doses and symptoms in Progress';

  @override
  String get profileSignInMethods => 'Sign-in methods';

  @override
  String get profileSignInMethodsSubtitle =>
      'Password, Google, Facebook and Apple';

  @override
  String get profilePrivacy => 'Privacy and data';

  @override
  String get profilePrivacySubtitle =>
      'Permissions, export and account deletion';

  @override
  String get profileNotifications => 'Notifications and reminders';

  @override
  String get profileNotificationsOn => 'On for this device';

  @override
  String get profileNotificationsOff => 'Off for this device';

  @override
  String get profileTheme => 'Theme';

  @override
  String get themeSystem => 'System';

  @override
  String get themeLight => 'Light';

  @override
  String get themeDark => 'Dark';

  @override
  String get profileAssistant => 'Assistant';

  @override
  String get profileAssistantSubtitle =>
      'Check your logs and ask questions about the app';

  @override
  String get profileHelpCenter => 'Help center';

  @override
  String get profileHelpCenterSubtitle => 'FAQs and how-to guides';

  @override
  String get profileServerStatusDev => 'Server status (development)';

  @override
  String get profileLogout => 'Sign out';

  @override
  String get profileLogoutConfirmTitle => 'Sign out?';

  @override
  String get profileLogoutConfirmMessage =>
      'You\'ll need to sign in again on this device.';
}
