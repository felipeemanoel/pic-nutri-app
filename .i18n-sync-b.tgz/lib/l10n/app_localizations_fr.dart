// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get languageTitle => 'Langue';

  @override
  String get languageChooseTitle => 'Choisissez la langue de l\'app';

  @override
  String get languageChooseSubtitle =>
      'Vous pouvez la modifier à tout moment dans Profil › Langue.';

  @override
  String get languageFollowDevice => 'Utiliser la langue de l\'appareil';

  @override
  String get languageInProgress => 'Traduction en cours';

  @override
  String get languageChange => 'Changer de langue';

  @override
  String get languageChangeShort => 'Modifier';

  @override
  String get authTagline => 'Un espace pour prendre soin de vous.';

  @override
  String get authFooter => 'Votre progression, à votre rythme.';

  @override
  String get onboardingWelcomeTitle => 'Construisons votre plan';

  @override
  String get onboardingWelcomeSubtitle =>
      'Répondez à quelques questions rapides et PicNutri s\'adapte à vous. Cela prend environ 2 minutes.';

  @override
  String get onboardingWelcomePhotoTitle => 'Enregistrez en photo';

  @override
  String get onboardingWelcomePhotoText =>
      'Photographiez votre assiette et voyez les calories et macros estimées.';

  @override
  String get onboardingWelcomeGoalsTitle => 'Des objectifs faits pour vous';

  @override
  String get onboardingWelcomeGoalsText =>
      'Calories, protéines et eau calculées à partir de vos données.';

  @override
  String get onboardingWelcomeProgressTitle => 'Suivez votre progression';

  @override
  String get onboardingWelcomeProgressText =>
      'Poids, mensurations et habitudes en graphiques simples.';

  @override
  String get actionStart => 'Commencer';

  @override
  String get actionStartUsing => 'Commencer à utiliser';

  @override
  String get actionContinue => 'Continuer';

  @override
  String get profileTitle => 'Profil';

  @override
  String get profileSectionAccount => 'Compte';

  @override
  String get profileSectionPreferences => 'Préférences';

  @override
  String get profileSectionHelp => 'Aide';

  @override
  String get profileGoals => 'Profil, objectif et cibles';

  @override
  String profileWater(String amount) {
    return 'Eau $amount';
  }

  @override
  String get profileMyPlan => 'Mon abonnement';

  @override
  String get profileProfessionals => 'Professionnels';

  @override
  String get profileProfessionalsSubtitle =>
      'Trouvez des diététiciens et des coachs sportifs';

  @override
  String get profileTrackMedication => 'Suivre un médicament';

  @override
  String get profileTrackMedicationSubtitle =>
      'Enregistrez les prises prescrites et les symptômes dans Progression';

  @override
  String get profileSignInMethods => 'Modes de connexion';

  @override
  String get profileSignInMethodsSubtitle =>
      'Mot de passe, Google, Facebook et Apple';

  @override
  String get profilePrivacy => 'Confidentialité et données';

  @override
  String get profilePrivacySubtitle =>
      'Autorisations, export et suppression du compte';

  @override
  String get profileNotifications => 'Notifications et rappels';

  @override
  String get profileNotificationsOn => 'Activées sur cet appareil';

  @override
  String get profileNotificationsOff => 'Désactivées sur cet appareil';

  @override
  String get profileTheme => 'Thème';

  @override
  String get themeSystem => 'Système';

  @override
  String get themeLight => 'Clair';

  @override
  String get themeDark => 'Sombre';

  @override
  String get profileAssistant => 'Assistant';

  @override
  String get profileAssistantSubtitle =>
      'Consultez vos données et posez vos questions sur l\'app';

  @override
  String get profileHelpCenter => 'Centre d\'aide';

  @override
  String get profileHelpCenterSubtitle =>
      'Questions fréquentes et guides d\'utilisation';

  @override
  String get profileServerStatusDev => 'État du serveur (développement)';

  @override
  String get profileLogout => 'Se déconnecter';

  @override
  String get profileLogoutConfirmTitle => 'Se déconnecter ?';

  @override
  String get profileLogoutConfirmMessage =>
      'Vous devrez vous reconnecter sur cet appareil.';
}
