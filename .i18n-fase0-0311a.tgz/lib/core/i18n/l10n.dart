import 'package:flutter/widgets.dart';

import '../../l10n/app_localizations.dart';

export '../../l10n/app_localizations.dart';

final _fallback = lookupAppLocalizations(const Locale('pt'));

extension L10nContext on BuildContext {
  /// Textos traduzidos da tela: `context.l10n.profileTitle`.
  ///
  /// Fora de um MaterialApp com os delegates (alguns testes de widget),
  /// usa o português, sem quebrar.
  AppLocalizations get l10n => AppLocalizations.of(this) ?? _fallback;
}
